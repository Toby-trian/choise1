<?php
foreach ($jawaban as $jwb) {
	echo $jwb->nama_paket;
}	
?>